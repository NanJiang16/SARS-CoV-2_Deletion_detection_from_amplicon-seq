# TrimGalore
A wrapper around Cutadapt and FastQC to consistently apply adapter and quality trimming to FastQ files, with extra functionality for RRBS data. Here is the new [Trim Galore User Guide](Docs/Trim_Galore_User_Guide.md).

Here is a link to the Trim Galore project page at The Babraham Institute: http://www.bioinformatics.babraham.ac.uk/projects/trim_galore/
